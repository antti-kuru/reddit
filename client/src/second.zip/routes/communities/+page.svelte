<script>
    import CommunityList from "$lib/components/communities/CommunityList.svelte";
    import AddCommunity from "$lib/components/communities/AddCommunity.svelte";
</script>

<h1>Communities</h1>

<CommunityList />
<AddCommunity />
