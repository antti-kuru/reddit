<script>
    let { data } = $props();
    import Community from "$lib/components/communities/Community.svelte";
    console.log(data);
    const communityId = parseInt(data.communityId);
    console.log(communityId);
</script>

<Community {communityId} />
