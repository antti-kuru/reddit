<script>
    let { data } = $props();
</script>
